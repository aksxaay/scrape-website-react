<!doctype html>
<html class="has-no-js" lang="en" data-template="error"  data-theme="light">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <base href="https://baillatstudio.com/">

    <title>Baillat</title>



    <link rel="canonical" href="https://baillatstudio.com/en" />
    <link rel="alternate" href="https://baillatstudio.com/fr" hreflang="fr" />

    <meta property="og:url" content="https://baillatstudio.com/">
    <meta property="og:title" content="Baillat">
    <meta property="og:image" content="https://baillatstudio.com/uploads/metadata/images/share.png">
    <meta property="og:description" content="">
    <meta name="image" content="https://baillatstudio.com/uploads/metadata/images/share.png">
    <meta name="description" content="">
    <meta name="twitter:image" content="https://baillatstudio.com/uploads/metadata/images/share.png">

    <!-- Viewport -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="HandheldFriendly" content="true">

    <!-- Appearance -->
    <meta name="theme-color" content="#ffffff">
    <meta name="msapplication-TileColor" content="#ffffff">
    <link rel="manifest" href="site.webmanifest" crossorigin="use-credentials">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/images/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/images/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicons/favicon-16x16.png">
    <link rel="mask-icon" href="assets/images/favicons/safari-pinned-tab.svg" color="#000000">

    <!-- Styles -->
    <style media="all">
        .c-loading{position:fixed;top:0;bottom:0;right:0;left:0;z-index:1000;pointer-events:none;opacity:0;transition:opacity 0.3s cubic-bezier(0.215, 0.61, 0.355, 1)}.is-first-load.is-loading-callback .c-loading{opacity:1;transition-delay:0s}@keyframes loadingSpinner{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}.c-loading_content{position:absolute;bottom:.625rem;right:.625rem;color:transparent;transition:color .3s cubic-bezier(0.215, 0.61, 0.355, 1)}.is-first-load.is-loading-callback .c-loading_content{color:#000}html[data-theme=&quot;dark&quot;].is-first-load.is-loading-callback .c-loading_content{color:#FAFAFA}.c-loading_content svg{width:1.5625rem;height:1.5625rem;fill:none;stroke:currentColor;stroke-width:calc(1px * 0.72);display:inline-block;vertical-align:middle;margin-left:.3125rem;animation:loadingSpinner 1s infinite}

    </style>

    <link id="stylesheet" rel="stylesheet"
        href="https://baillatstudio.com/assets/styles/main.css?v=202111091637" media="print"
        onload="this.media='all'; this.onload=null; this.isLoaded=true">

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-0BBN77KY2B"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'G-0BBN77KY2B');
    </script>

    <link rel="apple-touch-icon" sizes="180x180" href="assets/images/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/images/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicons/favicon-16x16.png">
    <link rel="manifest" href="assets/images/favicons/site.webmanifest">
    <link rel="mask-icon" href="assets/images/favicons/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="theme-color" content="#ffffff">

    <link rel="icon" href="assets/images/favicon.svg">

</head>

<body data-module-load style="opacity: 0;">

    <div class="c-loading">
        <span class="c-loading_content">
            Baillat Studio
            <svg role="img">
                <use href="assets/images/sprite.svg#spinner"></use>
            </svg>
        </span>
    </div>

    <div data-load-container data-theme="light">

        <span class="c-cursor" data-module-cursor>
            <span class="c-cursor_inner">
                <!-- <span class="c-cursor_label -play o-text -caps-big">
                    Play
                </span> -->
                <span class="c-cursor_icon -next">
                    <svg role="img">
                        <use xlink:href="assets/images/sprite.svg#arrow-right"></use>
                    </svg>
                </span>
                <span class="c-cursor_icon -prev">
                    <svg role="img">
                        <use xlink:href="assets/images/sprite.svg#arrow-left"></use>
                    </svg>
                </span>
            </span>
        </span>

        <div class="c-popup" data-module-popup>
            <div class="c-popup_background"></div>
            <div class="c-popup_container o-ratio u-16:9" data-popup="inner"></div>
            <button class="c-popup_close" type="button" data-popup="closeButton" aria-label="close popup">
                <svg role="img">
                    <use xlink:href="assets/images/sprite.svg#close-thin"></use>
                </svg>
            </button>
        </div>

        <button class="c-header_burger" data-module-nav-button type="button">
            <span class="u-screen-reader-text">Toggle menu</span>
            <span class="c-header_burger_inner">

            </span>
        </button>

        <nav class="c-nav">
            <div class="c-nav_layout o-layout">
                <button class="c-nav_close" data-module-nav-button type="button">
                    <svg role="img">
                        <use href="assets/images/sprite.svg#close-thin"></use>
                    </svg>
                </button>
                <div class="c-nav_col -border o-layout_item u-3/16@from-medium">
                    <div class="c-nav_col_main c-nav_logo">
                        <div class="o-layout">
                            <div class="o-layout_item u-1/2@from-medium">
                                <a class="c-link js-text-link" href="/en">
                                    Baillat Studio
                                </a>
                            </div>
                            <div class="o-layout_item u-1/2@from-medium u-text-right u-none@to-medium">
                                <a href="https://baillatstudio.com/fr" class="c-link js-text-link">
                                    Français
                                </a>
                            </div>
                        </div>
                    </div>
                    <p class="c-nav_footer u-none@to-medium">© 2021</p>
                </div>
                <div class="c-nav_col -main o-layout_item u-13/16@from-medium">
                    <div class="c-nav_col_main">
                        <ul class="c-nav_menu">
                            <li class="c-nav_menu_item">
                                <span class="c-nav_menu_link_wrap">
                                    <a href="/en/identity" class="c-nav_menu_link">
                                        <span class="c-nav_menu_link_main">Identity</span>
                                        <sup>39</sup>
                                    </a>
                                </span>
                                <span class="c-nav_menu_item_visual">
                                    <!-- 285px x 140px -->
                                    <span class="c-nav_menu_item_visual_inner"
                                        data-load-style="background-image:url('uploads/project/Video_Intra/2019_09_04_Baillat7138-420x190.jpg')">
                                    </span>
                                </span>
                            </li>
                            <li class="c-nav_menu_item">
                                <span class="c-nav_menu_link_wrap">
                                    <a href="/en/experience" class="c-nav_menu_link">
                                        <span class="c-nav_menu_link_main">Experience</span>
                                        <sup>17</sup>
                                    </a>
                                </span>
                                <span class="c-nav_menu_item_visual">
                                    <!-- 285px x 140px -->
                                    <span class="c-nav_menu_item_visual_inner"
                                        data-load-style="background-image:url('uploads/project/XP_EXPERIENCE/02_SPECTACLESETSCENOS/HELENE_FISCHER/HF_Header-420x190.jpg')">
                                    </span>
                                </span>
                            </li>
                            <li class="c-nav_menu_item">
                                <span class="c-nav_menu_link_wrap">
                                    <a href="/en/about" class="c-nav_menu_link">
                                        <span class="c-nav_menu_link_main">About</span>
                                    </a>
                                </span>
                                <span class="c-nav_menu_item_visual">
                                    <!-- 285px x 140px -->
                                    <span class="c-nav_menu_item_visual_inner"
                                        data-load-style="background-image:url('uploads/project/06_PROJETS_SPECIAUX/BAILLAT_3ANS/BAILLAT3ANS_2.1-420x190.jpg')">
                                    </span>
                                </span>
                            </li>
                            <li class="c-nav_menu_item">
                                <span class="c-nav_menu_link_wrap">
                                    <a href="/en/let-s-talk" class="c-nav_menu_link">
                                        <span class="c-nav_menu_link_main">Let's talk</span>
                                    </a>
                                </span>
                                <span class="c-nav_menu_item_visual">
                                    <!-- 285px x 140px -->
                                    <span class="c-nav_menu_item_visual_inner"
                                        data-load-style="background-image:url('uploads/project/Accueil/LAMBORGHINI_Posts_BaillatSTudio-01A-2-420x190.jpg')">
                                    </span>
                                </span>
                            </li>
        
                            <li class="c-nav_menu_item -lang u-none@from-medium">
                                <span class="c-nav_menu_link_wrap">
                                    <a href="https://baillatstudio.com/fr" class="c-nav_menu_link c-link js-text-link">
                                        Français
                                    </a>
                                </span>
                            </li>
                        </ul>
                    </div>
                    <div class="c-nav_footer o-layout -bottom">
                        <div class="o-layout_item u-7/13@from-medium u-1/2@to-medium">
                            <ul>
                                <li><a href="https://www.instagram.com/baillat_studio/" class="c-link js-text-link">Instagram</a></li>
                                <li><a href="https://www.behance.net/Baillat" class="c-link js-text-link">Behance</a></li>
                                <li><a href="https://vimeo.com/user38435259" class="c-link js-text-link">Vimeo</a></li>
                                <li><a href="https://ca.linkedin.com/company/baillat-studio" class="c-link js-text-link">LinkedIn</a></li>
                                <li><a href="https://fr-ca.facebook.com/BaillatStudio/" class="c-link js-text-link">Facebook</a></li>
                            </ul>
                        </div>
                        <div class="o-layout_item u-3/13@from-medium u-1/2@to-medium u-none@from-medium -top">
                            <a href="tel:+15148891853">+1 514 889 1853 <span class="c-arrow">
    <span class="c-arrow_part -main">
        &#x2197;&#xfe0e;
    </span>
    <span class="c-arrow_part -hover">
        &#x2197;&#xfe0e;
    </span>
</span></a>
                        </div>
                        <div class="o-layout_item u-3/13@from-medium u-1/2@to-medium u-none@from-medium">
                            <p>© Baillat Studio 2021</p>
                        </div>
                        <address class="o-layout_item u-3/13@from-medium u-1/2@to-medium">
                            <a href="https://goo.gl/maps/L2LG8VtQaoCKYrTn6" class="u-block" target="_blank" rel="noopener noreferer">
                                Baillat Studio<br />
6250 Hutchison<br />
espace 404<br />
Montréal, Canada
                                <span class="c-arrow">
                                    <span class="c-arrow_part -main">
                                        &#x2197;&#xfe0e;
                                    </span>
                                    <span class="c-arrow_part -hover">
                                        &#x2197;&#xfe0e;
                                    </span>
                                </span>                            </a>
                        </address>
                        <div class="o-layout_item u-3/13@from-medium u-none@to-medium">
                            <a href="tel:+15148891853">+1 514 889 1853 <span class="c-arrow">
    <span class="c-arrow_part -main">
        &#x2197;&#xfe0e;
    </span>
    <span class="c-arrow_part -hover">
        &#x2197;&#xfe0e;
    </span>
</span></a>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
<header class="c-header js-header" data-scroll-section>
    <div class="c-header_inner">
        <a class="c-header_logo" href="/en">
            <span class="c-link js-text-link">Baillat Studio</span>
        </a>
        <div class="c-header_container">
        </div>
    </div>
</header>
<main class="o-scroll" data-module-scroll="main">

    <div data-scroll-section>
        <div class="o-container">
            <div class="c-about-header">
                <h1 class="c-about-header_title || o-text -caps-big u-anim-title" data-module-split>
                    Page Not Found!
                </h1>
                <p class="o-text -caps-big u-anim-title" data-module-split>
                    The page you are looking for could not be found.
                </p>
            </div>
        </div>
    </div>


    <footer class="c-footer" data-scroll-section>
        <div class="o-container">
            <nav class="c-footer_nav">
                <ul class="c-footer_nav_ul">
                    <li class="c-footer_nav_li -identity u-anim -delay-2" data-scroll>
                        <a class="c-footer_main_link -ligatures c-link js-text-link"
                            href="/en/identity">Identity<sup>39</sup></a>
                        <ul class="c-footer_nav_sub">
                            <li>Edition</li>
                            <li>Website</li>
                            <li>Branding</li>
                            <li>Campaign</li>
                            <li>Packaging</li>
                            <li>Exhibitions</li>
                            <li>Special Projects</li>
                            <li>Motion</li>
                        </ul>
                    </li>
    
                    <li class="c-footer_nav_li -contact u-anim" data-scroll>
                        <a class="c-footer_main_link -ligatures c-link js-text-link" href="/en/let-s-talk">
                            <span>Let's</span>
                            <span>talk
                                <span class="c-arrow">
                                    <span class="c-arrow_part -main">
                                        &#x2197;&#xfe0e;
                                    </span>
                                    <span class="c-arrow_part -hover">
                                        &#x2197;&#xfe0e;
                                    </span>
                                </span>                            </span>
                        </a>
                    </li>
    
                    <li class="c-footer_nav_li -about u-anim" data-scroll>
                        <a class="c-footer_main_link -ligatures c-link js-text-link" href="/en/about">About</a>
                    </li>
                </ul>
            </nav>
            <div class="c-footer_infos || o-layout -gutter" data-scroll>
                <span class="o-layout_item u-3/16@from-small u-1/4@to-small u-anim -parent">©2021</span>
                <ul class="o-layout_item u-7/16@from-small u-3/4@to-small u-anim -parent -delay-2">
                            <li><a href="https://www.instagram.com/baillat_studio/" class="c-link js-text-link" target="_blank" rel="noopener noreferer">Instagram</a></li>
                            <li><a href="https://www.behance.net/Baillat" class="c-link js-text-link" target="_blank" rel="noopener noreferer">Behance</a></li>
                            <li><a href="https://vimeo.com/user38435259" class="c-link js-text-link" target="_blank" rel="noopener noreferer">Vimeo</a></li>
                            <li><a href="https://ca.linkedin.com/company/baillat-studio" class="c-link js-text-link" target="_blank" rel="noopener noreferer">LinkedIn</a></li>
                            <li><a href="https://fr-ca.facebook.com/BaillatStudio/" class="c-link js-text-link" target="_blank" rel="noopener noreferer">Facebook</a></li>
                </ul>
                <address class="o-layout_item u-2/8@from-small u-1/2@to-small || c-footer_address u-anim -parent -delay-4">
                    <a href="https://goo.gl/maps/L2LG8VtQaoCKYrTn6" target="_blank" rel="noopener noreferer">
                        Baillat Studio<br />
6250 Hutchison<br />
espace 404<br />
Montréal, Canada
                        <span class="c-arrow">
                            <span class="c-arrow_part -main">
                                &#x2197;&#xfe0e;
                            </span>
                            <span class="c-arrow_part -hover">
                                &#x2197;&#xfe0e;
                            </span>
                        </span>                    </a>
                </address>
                <div class="o-layout_item u-1/8@from-small u-1/2@to-small || c-footer_tel u-anim -parent -delay-6">
                    <a href="tel:+15148891853">+1 514 889 1853 <span class="c-arrow">
    <span class="c-arrow_part -main">
        &#x2197;&#xfe0e;
    </span>
    <span class="c-arrow_part -hover">
        &#x2197;&#xfe0e;
    </span>
</span></a>
                </div>
            </div>
        </div>
    </footer>
</main>

        </div>

        <script nomodule src="https://cdnjs.cloudflare.com/ajax/libs/babel-polyfill/7.6.0/polyfill.min.js" crossorigin="anonymous"></script>
        <script nomodule src="https://polyfill.io/v3/polyfill.min.js?features=fetch%2CCustomEvent%2CElement.prototype.matches%2CNodeList.prototype.forEach%2CAbortController" crossorigin="anonymous"></script>

        <script src="https://baillatstudio.com/assets/scripts/vendors.js?v=202111091637" defer></script>
        <script src="https://baillatstudio.com/assets/scripts/app.js?v=202111091637" defer></script>
    </body>
</html>